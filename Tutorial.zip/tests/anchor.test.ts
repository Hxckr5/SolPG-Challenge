import * as anchor from '@project-serum/anchor';
import { Program } from '@project-serum/anchor';
import { PublicKey, SystemProgram, Keypair } from '@solana/web3.js';

describe('PDA Moneybox Program', () => {
  // Configure the client to use the local cluster.
  const provider = anchor.Provider.local();
  anchor.setProvider(provider);

  // Import your program IDL and create the program object.
  const idl = JSON.parse(require('fs').readFileSync('./target/idl/pda_moneybox.json', 'utf8'));
  const programID = new anchor.web3.PublicKey(idl.metadata.address);
  const program = new Program(idl, programID, provider);

  let vault: Keypair;
  let user: Keypair;
  let tokenAccount1: PublicKey;
  let tokenAccount2: PublicKey;

  before(async () => {
    // Create a new vault and user account before each test.
    vault = Keypair.generate();
    user = Keypair.generate();

    // Fund the user account with SOL.
    await provider.connection.requestAirdrop(user.publicKey, 1000000000);

    // Create two token accounts (replace with actual token account creation).
    tokenAccount1 = await createTokenAccount(user, program.provider.wallet.publicKey);
    tokenAccount2 = await createTokenAccount(user, program.provider.wallet.publicKey);

    // Initialize the vault.
    await program.rpc.initialize({
      accounts: {
        vaultAccount: vault.publicKey,
        user: user.publicKey,
        systemProgram: SystemProgram.programId,
      },
      signers: [vault, user],
    });
  });

  it('should initialize the vault with a balance of 0', async () => {
    const vaultAccount = await program.account.vault.fetch(vault.publicKey);
    assert.ok(vaultAccount);
    assert.strictEqual(vaultAccount.balance, 0);
  });

  it('should deposit tokens into the vault', async () => {
    const initialBalance = 100;

    // Deposit tokens into the vault.
    await program.rpc.deposit(new anchor.BN(initialBalance), {
      accounts: {
        from: tokenAccount1,
        to: vault.publicKey,
        authority: program.provider.wallet.publicKey,
        tokenProgram: TokenInstructions.TOKEN_PROGRAM_ID,
      },
      signers: [],
    });

    // Verify the vault balance after deposit.
    const vaultAccount = await program.account.vault.fetch(vault.publicKey);
    assert.strictEqual(vaultAccount.balance, initialBalance);
  });

  // Helper function to create a token account (replace with actual function).
  async function createTokenAccount(owner: Keypair, tokenMint: PublicKey): Promise<PublicKey> {
    const token = new anchor.web3.PublicKey(TokenInstructions.TOKEN_PROGRAM_ID);
    const tokenAccount = await anchor.web3.Keypair.generate();

    const tx = anchor.web3.SystemProgram.createAccount({
      fromPubkey: owner.publicKey,
      newAccountPubkey: tokenAccount.publicKey,
      lamports: await provider.connection.getMinimumBalanceForRentExemption(anchor.web3.AccountLayout.span),
      space: anchor.web3.AccountLayout.span,
      programId: token,
    });

    const tx2 = TokenInstructions.TOKEN_PROGRAM_ID;
    await anchor.web3.sendAndConfirmTransaction(provider.connection, tx, [owner]);
    await TokenInstructions.TOKEN_PROGRAM_ID;

    return tokenAccount.publicKey;
  invest also
