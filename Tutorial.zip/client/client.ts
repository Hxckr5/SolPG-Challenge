import { Connection, PublicKey, clusterApiUrl, Keypair } from '@solana/web3.js';
import { Program, AnchorProvider, web3, BN } from '@project-serum/anchor';
import idl from './idl.json'; // Path to your IDL file

// Constants
const network = clusterApiUrl('devnet');
const connection = new Connection(network, 'processed');
const programID = new PublicKey(idl.metadata.address);

// Set up provider
const provider = AnchorProvider.env();
const wallet = provider
